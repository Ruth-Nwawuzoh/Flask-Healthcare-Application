import os
from dotenv import load_dotenv
from flask import Flask, render_template, request, redirect, url_for, flash
from pymongo import MongoClient

# Load environment variables
load_dotenv()

app = Flask(__name__)

# Set Flask secret key
app.secret_key = os.getenv("SECRET_FLASH_KEY", "fallback_secret_key")

# MongoDB connection
mongo_uri = os.getenv("MONGO_URI")
client = MongoClient(mongo_uri)
db = client["survey_db"]
collection = db["data"]

# Confirm MongoDB connection
try:
    client.admin.command('ping')
    print("Pinged your deployment. Successfully connected to MongoDB!")
except Exception as e:
    print(e)

# Routes
@app.route("/", methods=["GET", "POST"])
def survey():
    if request.method == "POST":
        try:
            # Collect form data
            data = {
                "age": int(request.form["age"]),
                "gender": request.form["gender"],
                "income": float(request.form["income"]),
                "expenses": {
                    "utilities": float(request.form.get("utilities", 0)),
                    "entertainment": float(request.form.get("entertainment", 0)),
                    "school_fees": float(request.form.get("school_fees", 0)),
                    "shopping": float(request.form.get("shopping", 0)),
                    "healthcare": float(request.form.get("healthcare", 0)),
                },
            }
            # Insert into MongoDB
            collection.insert_one(data)

            # Success message
            flash("Form submitted successfully!", "success")
        except Exception as e:
            flash(f"Error: {str(e)}. Please try again.", "danger")
        
        return redirect("/")
    
    return render_template("index.html")


@app.route('/submit', methods=['POST'])
def submit():
    if request.method == 'POST':
        user_data = {
            "age": request.form.get('age'),
            "gender": request.form.get('gender'),
            "income": request.form.get('income'),
            "expenses": {
                "utilities": request.form.get('utilities'),
                "entertainment": request.form.get('entertainment'),
                "school_fees": request.form.get('school_fees'),
                "shopping": request.form.get('shopping'),
                "healthcare": request.form.get('healthcare')
            }
        }
        collection.insert_one(user_data)

        return render_template('success.html', message="Form submission successful!")


if __name__ == "__main__":
    app.run(debug=True)
