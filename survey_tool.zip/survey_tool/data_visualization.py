# Import necessary libraries
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Read data from the CSV file
file_name = "survey_data.csv"
data = pd.read_csv(file_name)

# Display a preview of the dataset
print("Preview of the dataset:")
print(data.head())

# Visualization 1: Identifying age groups with the highest income
plt.figure(figsize=(12, 8))
sns.barplot(data=data, x='age', y='income', errorbar=None, hue='age', palette='viridis', legend=False)
plt.title('Income Distribution by Age ', fontsize=16)
plt.xlabel('Age', fontsize=12)      
plt.ylabel('Total Income', fontsize=12)
plt.xticks(rotation=45)  # Rotate x-axis labels for readability
plt.tight_layout()
plt.savefig('income_distribution_by_age.png')  # Save the figure as an image file
plt.show()

# Visualization 2: Comparing spending habits by gender across different categories
# Convert wide-format spending data into a long-format structure for easier visualization
spending_categories = ['utilities', 'entertainment', 'school_fees', 'shopping', 'healthcare']
spending_data = data.melt(id_vars=['gender'], value_vars=spending_categories, var_name='Category', value_name='Spending')

# Create a box plot to compare gender-based spending trends
plt.figure(figsize=(14, 8))
sns.boxplot(data=spending_data, x='Category', y='Spending', hue='gender', palette='magma')
plt.title('Gender Distribution across Spending', fontsize=18)
plt.xlabel('Spending Category', fontsize=11)
plt.ylabel('Amount Spent', fontsize=11)
plt.xticks(rotation=45)  # Adjust labels for better visibility
plt.legend(title='Gender')
plt.tight_layout()
plt.savefig('gender_distribution_across_spending.png')  # Save the second visualization
plt.show()

# Indicate that the visualizations have been saved successfully
print("Graphs saved as 'income_distribution_by_age.png' and 'gender_distribution_across_spending.png'")
